---
name: Solaris Modern
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45474c'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777c'
  outline-variant: '#c6c6cc'
  surface-tint: '#585e6e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#151c29'
  on-primary-container: '#7d8494'
  inverse-primary: '#c0c6d8'
  secondary: '#785900'
  on-secondary: '#ffffff'
  secondary-container: '#fdc003'
  on-secondary-container: '#6c5000'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#001159'
  on-tertiary-container: '#5d78ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce2f5'
  primary-fixed-dim: '#c0c6d8'
  on-primary-fixed: '#151c29'
  on-primary-fixed-variant: '#404756'
  secondary-fixed: '#ffdf9e'
  secondary-fixed-dim: '#fabd00'
  on-secondary-fixed: '#261a00'
  on-secondary-fixed-variant: '#5b4300'
  tertiary-fixed: '#dee1ff'
  tertiary-fixed-dim: '#bac3ff'
  on-tertiary-fixed: '#001159'
  on-tertiary-fixed-variant: '#0031c6'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 60px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
---

## Brand & Style

The brand identity centers on the intersection of sustainability and technological precision. It is designed to evoke a sense of optimism, reliability, and modern efficiency. The target audience includes homeowners seeking energy independence and commercial partners looking for high-performance infrastructure.

The design style is **Corporate / Modern** with a strong emphasis on **Minimalism**. It utilizes expansive white space to denote clarity and breathability, balanced by high-contrast accents that symbolize energy. The visual language is structured yet accessible, ensuring that complex solar data feels intuitive and trustworthy.

## Colors

The palette is anchored by a deep **Navy Primary (#121926)**, providing a foundation of stability and professional authority. This is contrasted by a vibrant **Solar Yellow (#FFC107)**, used sparingly for critical calls to action and highlights to represent energy and light.

An **Electric Blue (#4D6BFE)** serves as a tertiary color for secondary interactive elements and decorative gradients, bridging the gap between the dark navy and the bright yellow. The background remains predominantly **White (#FFFFFF)** or **Slate Tint (#F8FAFC)** to maintain a clean, high-end editorial feel.

## Typography

The design system utilizes **Hanken Grotesk** across all roles to ensure a cohesive, sharp, and modern aesthetic. Its clean geometry is highly legible at small sizes while remaining impactful in large display formats.

- **Headlines:** Use Bold (700) or Semi-Bold (600) weights with slightly tight letter spacing to create a commanding presence.
- **Body Text:** Use Regular (400) weight with generous line heights (1.6) to ensure maximum readability during long-form content consumption.
- **Labels:** Use Medium or Semi-Bold weights with increased letter spacing and uppercase styling for navigation, badges, and small supporting metadata.

## Layout & Spacing

This design system employs a **Fixed-Fluid Hybrid Grid**. On desktop, content is contained within a 12-column grid with a maximum width of 1280px to prevent excessive line lengths. 

- **Vertical Rhythm:** Built on an 8px base unit. Section spacing (XL) is used to create clear separation between different content blocks, while Medium (24px) spacing is the default for internal component padding.
- **Responsive Behavior:** 
  - **Desktop (1024px+):** 12 columns, 24px gutters, 48px+ margins.
  - **Tablet (768px - 1023px):** 8 columns, 20px gutters, 32px margins.
  - **Mobile (Up to 767px):** 4 columns, 16px gutters, 16px margins. Headlines scale down automatically to maintain visual balance.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and extremely **Ambient Shadows**. This design system avoids heavy drop shadows in favor of subtle depth that mimics natural light.

1.  **Level 0 (Base):** The primary canvas, typically white or the lightest neutral tint.
2.  **Level 1 (Cards/Surface):** White surfaces with a very soft, diffused shadow (0px 4px 20px rgba(18, 25, 38, 0.05)) or a 1px border in a light neutral tone.
3.  **Level 2 (Overlays/Modals):** Surfaces that sit above the UI, using a medium shadow (0px 12px 32px rgba(18, 25, 38, 0.12)) to provide clear focus.
4.  **Interactive States:** Subtle scale-up (1.02x) on hover combined with a slightly more intense shadow to simulate "lifting" toward the user.

## Shapes

The shape language is **Rounded**, strike a balance between friendly approachability and technical precision.

- **Standard Elements:** Buttons, input fields, and small cards use a 0.5rem (8px) radius.
- **Feature Containers:** Large section cards or image wrappers use a 1rem (16px) radius to create a softer, more modern "container" look.
- **Interactive Accents:** Pill shapes (full rounding) are reserved exclusively for status badges (e.g., "Active", "Pending") and small utility tags to distinguish them from primary action buttons.

## Components

### Buttons
- **Primary:** Solar Yellow background with Navy text. Bold weight. High contrast for primary conversions.
- **Secondary:** Navy background with White text. Used for main site navigation and secondary actions.
- **Ghost:** Transparent background with Navy border and text. Used for less critical actions.

### Input Fields
- **Default State:** White background with a 1px border in Neutral-300. Placeholder text in Text-Secondary.
- **Focus State:** 1px Primary Navy border with a subtle Solar Yellow outer glow (2px) to signal activity.

### Cards
- **Product Cards:** Minimalist white backgrounds, 1px soft borders, and center-aligned content. Imagery should be high-resolution with consistent lighting.
- **Feature Cards:** Use light Slate-Tint backgrounds to separate them from the main page flow.

### Chips & Badges
- Used for categories or technical specs. Small font size (Label-md), pill-shaped, with low-saturation backgrounds (e.g., light blue or light grey) to prevent them from competing with buttons.

### Progress & Data Viz
- Use the Tertiary Blue and Solar Yellow for charts. Progress bars should have rounded ends and utilize gradients to represent "flow" or "energy generation."